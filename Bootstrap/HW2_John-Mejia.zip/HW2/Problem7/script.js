// Cycle carousel through images banner_1.png, banner_2.png, banner_3.png every 2 seconds

$(document).ready(function() {
    $('.carousel').carousel({
        interval: 1000

    })
});

